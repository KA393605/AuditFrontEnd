export const server = {
    baseURL: 'https://rpa-audit.devk8s.gsk.com'
}