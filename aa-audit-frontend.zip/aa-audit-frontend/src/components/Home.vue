<template>
    <div >
        <div v-if="message">
            <div class="clearfix">
            <div> <img :src="image" />
            <h3>Successfully Logged In</h3></div>
            <button type="button" class="btn fl btn-link" @click="logout">Logout</button>
            </div>
            <hr><br>
            <form class="form-inline">
             <label for="email" class="mr-sm-2">From Date:</label><input type="date" class="form-control mb-2 mr-sm-2" placeholder="From Date" v-model="from_date" />
             <label for="email" class="mr-sm-2 indate">To Date:</label><input type="date" class="form-control mb-2 mr-sm-2" placeholder="To Date" v-model="to_date" @change="checktoDate"/>
            </form>
             <p>* Choose a proper interval to Audit</p><br>
            <label for="email" class="mr-sm-2">Functional Account</label>
            <input type="text" placeholder="Enter MudId" class="form-control mb-2 mr-sm-2 inputtxt" v-model="text"/>
           
            <button :disabled="invalid" @click="submit__Audit" class="btn btn-primary">AUDIT</button>
        </div>
        <div v-else>
            <h2>Login Failed due to : {{error_message}}</h2>
        </div>
        <div v-if="display">
            <hr>
            <h4>{{result}}</h4>
        </div>
    </div>
</template>
 
<script>
import image from "../assets/logo.png"
import axios from "axios";
import { server } from "../helper";
import router from "../router";
export default {
    name:'Home',
    data(){
        return{
            image: image,
            message:false,
            from_date:'',
            to_date:'',
            invalid:true,
            display:false,
            text:'',
            error_message:'',
            result:''
        }
    },
    created(){
        if(this.$route.params.message==="SUCCESS"){
            this.message=true
        }
        else{
            this.error_message=this.$route.params.message;
        }
    },
    methods:{
        checktoDate(){
            this.invalid=new Date(this.from_date) > new Date(this.to_date);
        },
        submit__Audit(){
            let data={
                fromDate:this.from_date+"T00:00:00Z",
                toDate:this.to_date+"T00:00:00Z",
                func_account:this.text
            };
             axios
            .post(`${server.baseURL}/api-call/fetchAuditAPI`, data)
            .then((data)=>{
                this.result=data.data;
                this.display=true;
            })
            .catch((error)=>{
                   this.result=error
            })
        },
        logout(){
             router.push('/create');
        }
    }
}
</script>
 
<style scoped>
form{
    margin-left: 30%;
}
 
.indate{
    margin-left: 20px;
}
 
.inputtxt{
    margin-left: 40%;
    width: 20%;
}
img{
 
  height: 100px;
  width: 100px;
}
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}
.fl{
float: right;
margin-top: -50px;
margin-right: 30px;
}
</style>